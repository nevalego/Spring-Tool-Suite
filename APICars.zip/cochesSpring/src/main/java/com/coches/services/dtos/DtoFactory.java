package com.coches.services.dtos;

public interface DtoFactory {
    DtoAssemblerCar getCars();
}