package com.coches.services;

import org.springframework.stereotype.Service;

public interface ServiceFactory {
	    
	    CarsService getCoches();

}
