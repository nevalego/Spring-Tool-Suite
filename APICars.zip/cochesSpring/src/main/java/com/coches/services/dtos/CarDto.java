package com.coches.services.dtos;

public class CarDto {
	
	
	public Long id;
	public String matricula;
	public String modelo;
	public int caballos;
}
